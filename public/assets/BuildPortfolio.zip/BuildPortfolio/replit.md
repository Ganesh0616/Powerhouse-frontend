# MERN Stack Developer Portfolio

## Overview

This is a full-stack developer portfolio application built with the MERN stack (MongoDB, Express.js, React, Node.js). The application showcases a modern, single-page portfolio website with sections for About, Skills, Projects, and Contact. It features a clean, professional design with dark/light theme support and includes a contact form with server-side message persistence.

The application is designed as a developer portfolio template, demonstrating proficiency in modern web development practices including responsive design, component-based architecture, and full-stack integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, providing fast HMR (Hot Module Replacement)
- **Wouter** for lightweight client-side routing (alternative to React Router)
- **TanStack Query** (React Query) for server state management and API data fetching

**UI Component System**
- **Shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design system
- **Class Variance Authority (CVA)** for managing component variants
- Custom theme system supporting light/dark modes with localStorage persistence

**Design System**
- Typography: Inter (body text) and Space Grotesk (headings) via Google Fonts
- Responsive grid layouts with mobile-first approach
- Custom color system using CSS variables for theme switching
- Consistent spacing scale using Tailwind's spacing units

**State Management**
- React Context API for theme management (ThemeProvider)
- Local component state for form handling
- TanStack Query for async state and caching

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript for type-safe server development
- RESTful API design pattern
- Middleware for JSON parsing, URL encoding, and request logging

**API Endpoints**
- `POST /api/contact` - Submit contact form messages
- `GET /api/contact/messages` - Retrieve all contact messages (admin functionality)

**Development Environment**
- Development mode uses Vite middleware for SSR and HMR
- Production mode serves static built files
- Custom request logging middleware tracking response times and payloads

**Data Validation**
- **Zod** schemas for runtime type validation
- **Drizzle-Zod** integration for deriving validation schemas from database schemas
- Server-side validation of all API inputs

### Data Storage Solutions

**Database Configuration**
- Configured to use **PostgreSQL** via Drizzle ORM
- Connection via **Neon Serverless** driver for serverless PostgreSQL
- Schema migrations managed through Drizzle Kit

**Database Schema**
- `users` table: Basic user authentication structure (id, username, password)
- `contact_messages` table: Contact form submissions (id, name, email, subject, message, createdAt)
- UUID primary keys using PostgreSQL's `gen_random_uuid()`

**Data Access Layer**
- Abstract `IStorage` interface defining data operations
- `MemStorage` implementation for in-memory development/testing (currently active)
- Designed for easy swap to database-backed storage without changing business logic
- TypeScript types generated from Drizzle schema for type safety

**Rationale for Dual Storage**
The in-memory storage pattern allows rapid development and testing without database dependencies, while the PostgreSQL schema ensures production-ready infrastructure. This approach enables developers to work offline and simplifies deployment scenarios.

### Design Patterns

**Component Architecture**
- Atomic design methodology with reusable UI components in `/components/ui`
- Feature components in `/components` combining UI primitives
- Page components in `/pages` orchestrating feature components
- Example components in `/components/examples` for documentation/testing

**Code Organization**
- Monorepo structure with shared code in `/shared`
- Client code in `/client`, server code in `/server`
- Path aliases (`@/`, `@shared/`, `@assets/`) for clean imports
- Separation of concerns: UI, business logic, and data layers

**Type Safety**
- End-to-end TypeScript with strict mode enabled
- Shared types between client and server via `/shared/schema.ts`
- Zod schemas serving as single source of truth for data validation

## External Dependencies

### Third-Party UI Libraries
- **Radix UI** - Comprehensive collection of accessible, unstyled UI primitives
- **Lucide React** - Icon library for consistent iconography
- **React Icons** - Additional icons (specifically Simple Icons for tech logos)
- **Embla Carousel** - Carousel/slider functionality
- **CMDK** - Command menu component

### Database & ORM
- **Neon Serverless** - PostgreSQL database driver optimized for serverless environments
- **Drizzle ORM** - TypeScript ORM for type-safe database operations
- **Drizzle Kit** - Migration and schema management tooling

### Development Tools
- **Replit Plugins** - Development banners, error overlays, and cartographer for Replit environment
- **ESBuild** - Fast JavaScript bundler for production server builds
- **TSX** - TypeScript execution engine for development server

### Utility Libraries
- **date-fns** - Date manipulation and formatting
- **nanoid** - Unique ID generation
- **clsx** & **tailwind-merge** - Conditional class name utilities

### Form Management
- **React Hook Form** - Performant form state management
- **@hookform/resolvers** - Validation resolver integration (Zod)

### Fonts
- Google Fonts integration for Inter, Space Grotesk, DM Sans, Architects Daughter, Fira Code, and Geist Mono

### Notable Design Decisions
- In-memory storage currently active instead of PostgreSQL (allows development without database setup)
- Single-page application design with smooth scroll navigation
- Custom theme system built on CSS variables rather than third-party theme library
- Path-based routing with Wouter instead of hash-based for cleaner URLs
- Query-based data fetching with automatic caching and revalidation