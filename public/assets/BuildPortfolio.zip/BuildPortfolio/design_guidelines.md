# MERN Stack Developer Portfolio - Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based with modern developer portfolio inspiration

Drawing from industry-leading developer portfolios (Vercel, Linear engineers, modern agency sites), this design prioritizes clean sophistication, strategic use of whitespace, and prominent project showcases. The portfolio balances technical credibility with visual impact to appeal to recruiters, clients, and fellow developers.

**Core Principles:**
- Bold typography hierarchy to establish professional authority
- Generous breathing room around key content
- Strategic visual anchors (project images, skill visualizations)
- Seamless single-page navigation experience

---

## Typography System

**Font Stack:**
- Primary: Inter (via Google Fonts) - for all body text, navigation, UI elements
- Display: Space Grotesk (via Google Fonts) - for hero headlines, section titles

**Hierarchy:**
- Hero Headline: Space Grotesk, 4xl/5xl/6xl responsive (font-bold, leading-tight)
- Section Headings: Space Grotesk, 3xl/4xl responsive (font-bold)
- Subsection Titles: Inter, xl/2xl (font-semibold)
- Body Text: Inter, base/lg (font-normal, leading-relaxed)
- Captions/Meta: Inter, sm (font-medium)
- Code/Tech Tags: Monospace fallback, xs/sm (font-mono)

---

## Layout System

**Spacing Primitives:**
Use Tailwind units: 2, 4, 6, 8, 12, 16, 20, 24, 32

**Container Strategy:**
- Full-width sections with `max-w-7xl mx-auto px-6 lg:px-8`
- Content sections: `py-20 lg:py-32` for desktop vertical rhythm
- Mobile sections: `py-12 md:py-16`
- Component internal spacing: `gap-6` to `gap-12` based on content density

**Grid Patterns:**
- Projects: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8`
- Skills: `grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4`
- Contact: `grid-cols-1 lg:grid-cols-2 gap-12` (form + info split)

---

## Component Library

### Navigation
Fixed header with blur backdrop, containing logo/name, smooth-scroll nav links (About, Skills, Projects, Contact), and prominent "Download Resume" CTA button. Mobile: hamburger menu with full-screen overlay navigation.

### Hero Section (Viewport: 85vh)
**Layout:** Center-aligned content with large display typography
**Content Structure:**
- Name/Title (Space Grotesk, text-6xl)
- Tagline: "MERN Stack Developer | Building Modern Web Applications"
- Two-sentence introduction emphasizing expertise
- CTA button group: "View Projects" (primary), "Get in Touch" (secondary with blurred background)
- Scroll indicator at bottom

**Background:** Subtle grid pattern or geometric shapes (CSS-based, not image)

### About Section
**Layout:** Two-column grid on desktop (60/40 split)

**Left Column:**
- Section heading: "About Me"
- 2-3 paragraphs about background, passion for development, approach to building applications
- Key stats grid (2x2): Years of Experience, Projects Completed, Technologies Mastered, Coffee Consumed

**Right Column:**
- Professional headshot placeholder (rounded-lg, aspect-square, grayscale effect)
- Current status badge: "Available for Opportunities"

### Skills Section
**Layout:** Full-width with category groupings

**Skill Categories** (each as separate subsection):
1. **Core MERN Stack:** MongoDB, Express.js, React, Node.js - displayed as prominent cards with icons
2. **Frontend Technologies:** HTML5, CSS3, JavaScript ES6+, Tailwind CSS, Redux, Next.js
3. **Backend & Databases:** RESTful APIs, GraphQL, PostgreSQL, JWT Authentication
4. **Tools & Workflow:** Git, GitHub, Docker, VS Code, Postman, npm/yarn

**Card Design:** 
- Icon at top (use Heroicons or Font Awesome via CDN)
- Technology name (font-semibold)
- Proficiency visualization: horizontal bar indicator
- Compact spacing: `p-4` to `p-6`

### Projects Showcase (Primary Focus Section)
**Layout:** Masonry-style grid with featured projects

**Project Card Structure:**
- Project image/screenshot (aspect-video, rounded-xl, hover lift effect)
- Project title (text-xl, font-bold)
- Brief description (2-3 lines, text-sm)
- Tech stack tags: pill-shaped badges with `px-3 py-1, text-xs, rounded-full`
- Action links: "Live Demo" and "GitHub" with arrow icons

**Featured Projects:** 4-6 projects, alternating between 2-column and 3-column layouts for visual interest

### Contact Section
**Layout:** Two-column split on desktop

**Left Column - Contact Form:**
- Fields: Name, Email, Subject, Message (all full-width with consistent spacing)
- Input styling: `p-4, rounded-lg, border, focus:ring-2`
- Submit button: full-width, prominent
- Form validation indicators

**Right Column - Contact Information:**
- Section title: "Let's Connect"
- Email address with icon
- GitHub profile link
- LinkedIn profile link
- Location (city/region)
- Availability status
- Response time expectation: "I typically respond within 24 hours"

### Footer
**Layout:** Three-column grid

**Columns:**
1. **Brand Column:** Name/logo, brief tagline, social media icons (GitHub, LinkedIn, Twitter)
2. **Quick Links:** Navigation shortcuts to all sections
3. **Additional Info:** Resume download link, email contact, copyright notice

**Spacing:** `py-12, border-t`

---

## Images

**Hero Section:** No large hero image - use CSS-based geometric background or gradient mesh

**About Section:** 
- Professional headshot (400x400px, modern professional photo, slight vignette effect)

**Projects Section (Critical):**
- 4-6 project screenshots/mockups (1200x675px, 16:9 aspect ratio)
- High-quality application interface screenshots showing responsive design
- Clean browser chrome or device mockups preferred
- Each image should clearly show the project's UI/functionality

**Placeholder Guidance:** Use `https://placehold.co/1200x675` for project images during development

---

## Interactions & Animations

**Minimal Animation Strategy:**
- Smooth scroll behavior for navigation
- Project cards: subtle hover lift (`hover:translate-y-[-4px]`) with transition
- CTA buttons: scale on hover (`hover:scale-105`)
- Section entrance: fade-up on scroll (use Intersection Observer)
- Skill bars: animate width on viewport entry
- Navigation: smooth color/background transitions

**No Distracting Elements:** Avoid parallax, excessive particle effects, or continuous animations

---

## Accessibility & Quality Standards

- All interactive elements: minimum 44px touch target
- Form inputs: clear focus states with ring utilities
- Semantic HTML throughout (header, nav, main, section, footer)
- Skip to content link for keyboard navigation
- ARIA labels for icon-only buttons
- Sufficient contrast ratios (ensure with final color choices)
- Responsive images with proper alt text

---

## Icon Library

**Selected Library:** Heroicons (via CDN)
- Use outline style for navigation, links, social media
- Use solid style for buttons, emphasis points
- Consistent sizing: `w-5 h-5` for inline, `w-8 h-8` for feature icons

---

This comprehensive design creates a polished, professional developer portfolio that showcases MERN stack expertise through strategic visual hierarchy, prominent project displays, and clean modern aesthetics that will impress recruiters and clients alike.