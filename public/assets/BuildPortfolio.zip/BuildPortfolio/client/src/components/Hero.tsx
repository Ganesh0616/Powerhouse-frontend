import { Button } from "@/components/ui/button";
import { ArrowRight, Mail, ChevronDown } from "lucide-react";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="hero"
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20 text-center relative z-10">
        <div className="space-y-6">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-tight">
            <span className="block">Full-Stack Developer</span>
            <span className="block text-primary">MERN Stack Specialist</span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Building Modern Web Applications | MongoDB, Express.js, React, Node.js
          </p>
          
          <p className="text-base md:text-lg max-w-3xl mx-auto leading-relaxed">
            I create scalable, high-performance web applications with clean code and intuitive user experiences. 
            Passionate about turning complex problems into elegant digital solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
            <Button
              size="lg"
              onClick={() => scrollToSection("projects")}
              className="min-w-[180px] gap-2"
              data-testid="button-view-projects"
            >
              View Projects
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => scrollToSection("contact")}
              className="min-w-[180px] gap-2 bg-background/50 backdrop-blur-sm"
              data-testid="button-get-in-touch"
            >
              <Mail className="w-4 h-4" />
              Get in Touch
            </Button>
          </div>
        </div>
        
        <button
          onClick={() => scrollToSection("about")}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 hover-elevate active-elevate-2 p-2 rounded-full animate-bounce"
          data-testid="button-scroll-down"
        >
          <ChevronDown className="w-6 h-6 text-muted-foreground" />
        </button>
      </div>

      <style>{`
        .bg-grid-pattern {
          background-image: 
            linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px),
            linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px);
          background-size: 4rem 4rem;
        }
      `}</style>
    </section>
  );
}
