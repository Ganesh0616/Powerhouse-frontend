import { Card } from "@/components/ui/card";
import { SiMongodb, SiExpress, SiReact, SiNodedotjs, SiGit, SiDocker } from "react-icons/si";
import { Code, Terminal, Database, Package } from "lucide-react";

export default function Skills() {
  const coreSkills = [
    { name: "MongoDB", icon: SiMongodb, color: "text-[#47A248]", level: 90 },
    { name: "Express.js", icon: SiExpress, color: "text-foreground", level: 95 },
    { name: "React", icon: SiReact, color: "text-[#61DAFB]", level: 95 },
    { name: "Node.js", icon: SiNodedotjs, color: "text-[#339933]", level: 90 },
  ];

  const frontendSkills = [
    "JavaScript ES6+",
    "TypeScript",
    "HTML5 & CSS3",
    "Tailwind CSS",
    "Redux",
    "Next.js",
  ];

  const backendSkills = [
    "RESTful APIs",
    "GraphQL",
    "PostgreSQL",
    "JWT Authentication",
    "WebSocket",
    "Microservices",
  ];

  const tools = [
    { name: "Git", icon: SiGit },
    { name: "Docker", icon: SiDocker },
    { name: "VS Code", icon: Code },
    { name: "npm/yarn", icon: Package },
  ];

  return (
    <section id="skills" className="py-20 lg:py-32 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4" data-testid="text-skills-title">
            Skills & Technologies
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A comprehensive toolkit for building modern web applications
          </p>
        </div>

        <div className="space-y-12">
          <div>
            <h3 className="text-2xl font-display font-bold mb-6 text-center">Core MERN Stack</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {coreSkills.map((skill) => {
                const Icon = skill.icon;
                return (
                  <Card key={skill.name} className="p-6 hover-elevate" data-testid={`card-skill-${skill.name.toLowerCase().replace(/\./g, '')}`}>
                    <div className="flex flex-col items-center text-center gap-4">
                      <Icon className={`w-12 h-12 ${skill.color}`} />
                      <div className="w-full">
                        <div className="font-semibold mb-2">{skill.name}</div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-primary rounded-full h-2 transition-all duration-500"
                            style={{ width: `${skill.level}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="p-8">
              <h3 className="text-xl font-bold mb-6">Frontend Technologies</h3>
              <div className="grid grid-cols-2 gap-3">
                {frontendSkills.map((skill) => (
                  <div
                    key={skill}
                    className="px-4 py-2 bg-muted rounded-md text-sm font-medium hover-elevate"
                    data-testid={`badge-frontend-${skill.toLowerCase().replace(/[\s&+.]/g, '-')}`}
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-8">
              <h3 className="text-xl font-bold mb-6">Backend & Database</h3>
              <div className="grid grid-cols-2 gap-3">
                {backendSkills.map((skill) => (
                  <div
                    key={skill}
                    className="px-4 py-2 bg-muted rounded-md text-sm font-medium hover-elevate"
                    data-testid={`badge-backend-${skill.toLowerCase().replace(/[\s&]/g, '-')}`}
                  >
                    {skill}
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 text-center">Tools & Workflow</h3>
            <div className="flex flex-wrap justify-center gap-6">
              {tools.map((tool) => {
                const Icon = tool.icon;
                return (
                  <div
                    key={tool.name}
                    className="flex items-center gap-2 px-6 py-3 bg-card rounded-lg hover-elevate"
                    data-testid={`tool-${tool.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tool.name}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
