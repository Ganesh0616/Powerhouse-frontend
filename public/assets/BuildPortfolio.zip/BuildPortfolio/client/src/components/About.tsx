import { Card } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import headshot from "@assets/generated_images/Professional_developer_headshot_portrait_54f8f946.png";

export default function About() {
  const stats = [
    { label: "Years Experience", value: "3+" },
    { label: "Projects Completed", value: "25+" },
    { label: "Technologies", value: "15+" },
    { label: "Coffee Consumed", value: "∞" },
  ];

  return (
    <section id="about" className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
          <div className="lg:col-span-3 space-y-6">
            <h2 className="text-3xl md:text-4xl font-display font-bold" data-testid="text-about-title">
              About Me
            </h2>
            
            <div className="space-y-4 text-base md:text-lg leading-relaxed">
              <p>
                I'm a passionate full-stack developer specializing in the MERN stack, 
                dedicated to crafting exceptional web experiences. With a strong foundation 
                in both frontend and backend technologies, I transform ideas into robust, 
                scalable applications.
              </p>
              
              <p>
                My journey in web development has taught me the importance of clean code, 
                user-centric design, and continuous learning. I thrive on solving complex 
                problems and building applications that make a real impact.
              </p>
              
              <p className="text-muted-foreground">
                When I'm not coding, you'll find me exploring new technologies, contributing 
                to open-source projects, or sharing knowledge with the developer community.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6">
              {stats.map((stat) => (
                <Card key={stat.label} className="p-6 text-center" data-testid={`card-stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="text-2xl md:text-3xl font-bold text-primary">
                    {stat.value}
                  </div>
                  <div className="text-xs md:text-sm text-muted-foreground mt-1">
                    {stat.label}
                  </div>
                </Card>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 flex flex-col items-center gap-6">
            <Avatar className="w-64 h-64 border-4 border-border" data-testid="img-profile">
              <AvatarImage src={headshot} alt="Developer profile" />
              <AvatarFallback>DEV</AvatarFallback>
            </Avatar>
            
            <Badge variant="secondary" className="text-sm px-4 py-2" data-testid="badge-availability">
              Available for Opportunities
            </Badge>
          </div>
        </div>
      </div>
    </section>
  );
}
