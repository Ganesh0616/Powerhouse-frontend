import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";
import ecommerce from "@assets/generated_images/E-commerce_platform_project_screenshot_cec57432.png";
import social from "@assets/generated_images/Social_media_dashboard_screenshot_07d17823.png";
import task from "@assets/generated_images/Task_management_app_screenshot_61dfb868.png";
import analytics from "@assets/generated_images/Analytics_dashboard_project_screenshot_90832838.png";
import weather from "@assets/generated_images/Weather_app_project_screenshot_b1989931.png";
import blog from "@assets/generated_images/Blog_CMS_project_screenshot_27800ee2.png";

export default function Projects() {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "Full-featured online store with product management, shopping cart, and secure payment integration.",
      image: ecommerce,
      tech: ["React", "Node.js", "MongoDB", "Stripe"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Social Media Dashboard",
      description: "Real-time social platform with user authentication, posts, comments, and notifications system.",
      image: social,
      tech: ["React", "Express", "MongoDB", "Socket.io"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Task Management App",
      description: "Collaborative project management tool with drag-and-drop kanban boards and team features.",
      image: task,
      tech: ["React", "Node.js", "PostgreSQL", "Redux"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Analytics Dashboard",
      description: "Data visualization platform with real-time metrics, charts, and comprehensive reporting.",
      image: analytics,
      tech: ["React", "Express", "MongoDB", "Chart.js"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Weather Forecast App",
      description: "Beautiful weather application with location-based forecasts and detailed meteorological data.",
      image: weather,
      tech: ["React", "Node.js", "Weather API", "Tailwind"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Blog CMS",
      description: "Content management system with rich text editor, media handling, and SEO optimization.",
      image: blog,
      tech: ["React", "Express", "MongoDB", "AWS S3"],
      liveUrl: "#",
      githubUrl: "#",
    },
  ];

  return (
    <section id="projects" className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4" data-testid="text-projects-title">
            Featured Projects
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A showcase of recent work demonstrating full-stack development expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={project.title}
              className="overflow-hidden hover-elevate group"
              data-testid={`card-project-${index}`}
            >
              <div className="aspect-video overflow-hidden bg-muted">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              </div>
              
              <div className="p-6 space-y-4">
                <h3 className="text-xl font-bold" data-testid={`text-project-title-${index}`}>
                  {project.title}
                </h3>
                
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech) => (
                    <Badge
                      key={tech}
                      variant="secondary"
                      className="text-xs"
                      data-testid={`badge-tech-${tech.toLowerCase()}-${index}`}
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex gap-3 pt-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="flex-1 gap-2"
                    data-testid={`button-live-${index}`}
                  >
                    <ExternalLink className="w-4 h-4" />
                    Live Demo
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-2"
                    data-testid={`button-github-${index}`}
                  >
                    <Github className="w-4 h-4" />
                    GitHub
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
