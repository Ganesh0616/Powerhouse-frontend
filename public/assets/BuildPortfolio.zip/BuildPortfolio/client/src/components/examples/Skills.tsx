import Skills from "../Skills";

export default function SkillsExample() {
  return <Skills />;
}
